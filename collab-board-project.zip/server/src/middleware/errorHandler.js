export const errorHandler = (err, req, res, next) => {
    console.error(err.message)
    res.status(err.status || 500).json({
        error: {
            message: err.message || 'Internal server error'
        }
    })
}